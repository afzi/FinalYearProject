module.exports = {


    friendlyName: 'View account overview',


    description: 'Display "Account Overview" page.',


    exits: {

        success: {
            viewTemplatePath: 'pages/account/account-overview',
        }

    },


    fn: async function() {
        return {
            title: 'Account Overview'
        };

    }


};