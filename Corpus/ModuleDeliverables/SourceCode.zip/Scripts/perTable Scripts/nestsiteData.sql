TRUNCATE TABLE nestsite;
INSERT INTO nestsite 
(nestID, nestDescription, distanceToHoppersKm, latitude, longitude, createdBy, editedBy) VALUES
('novigrad','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendum rutrum.',1.23,-20.348404,57.552151,3,null),
('whiterun','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendum rutrum.',0.5,-27.348404,57.552151,6,3),
('oxenfurt','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendum rutrum.',0.11,-21.348404,57.552151,3,null),
('solitude','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendum rutrum.',0.36,-28.348404,53.552151,6,null),
('temeria','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendumm rutrum.',3.14,-22.348404,-14.552151,3,null),
('vizima','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentumm bibendumm rutrum.',2.5,-26.348404,58.552151,4,null),
('kronos','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendumm rutrumm.',12,-23.348404,52.552151,3,6),
('riverwood','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibendm rutrum.',2,21.348404,51.552151,4,null),
('kaer morhen','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fermentum bibum rutrum.',1,-24.348404,57.552151,3,null);