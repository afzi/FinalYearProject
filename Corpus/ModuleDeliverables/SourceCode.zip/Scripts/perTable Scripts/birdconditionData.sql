TRUNCATE TABLE birdcondition;
INSERT INTO birdcondition 
(createdAt,updatedAt,id,birdCondition,birdID) VALUES
(1549094046,1550275200,1,'Broken Right Wing, claiming bridifits.',3),
(1549094046,null,2,'Seems to be possessed with the sprit of the ghost rider.',2),
(1549097646,1550275200,3,'all good.',1),
(1549097646,null,4,'wearing an eyepatch.',30),
(1549097646,null,5,'bit a researcher, it was funny.',3),
(1549097646,null,6,'second toe on left foot appears injured.',26),
(1549529646,1550275200,7,'had a fight with a pigeon, the pigeon did not survive. this bird is now know as the punisher amoung it\'s peers.',12),
(1549238400,null,8,'has a bit of a drinking problem.',11),
(1549529646,null,9,'been eating a lot of seeds, struggling to fly. Suggesting a membership to PureGym.',11),
(1549875246,1550275200,10,'Much Health. Such Wow.',4),
(1549529646,null,11,'running out of ideas',6),
(1549875246,null,12,'upon further inspection it might actually be pregnant.',11);